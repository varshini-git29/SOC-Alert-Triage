import os
import re

backend_path = r"c:\Users\nagav\Downloads\soc-alert-triage-main\soc-alert-triage-main\backend\app"

for root, dirs, files in os.walk(backend_path):
    for file in files:
        if file.endswith('.py'):
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                original = content
                
                # Replace "from app." with relative imports
                content = re.sub(r'^from app\.', 'from .', content, flags=re.MULTILINE)
                # Handle "from app" followed by space (like "from app import")
                content = re.sub(r'^from app\s', 'from . ', content, flags=re.MULTILINE)
                
                if original != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"Fixed: {filepath}")
            except Exception as e:
                print(f"Error processing {filepath}: {e}")

print("All imports fixed!")
