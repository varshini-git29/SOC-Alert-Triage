import os
import re
from pathlib import Path

backend_path = r"c:\Users\nagav\Downloads\soc-alert-triage-main\soc-alert-triage-main\backend\app"
base_path = r"c:\Users\nagav\Downloads\soc-alert-triage-main\soc-alert-triage-main"

for root, dirs, files in os.walk(backend_path):
    for file in files:
        if file.endswith('.py'):
            filepath = os.path.join(root, file)
            try:
                # Calculate relative depth from backend/app
                rel_path = os.path.relpath(filepath, backend_path)
                depth = rel_path.count(os.sep)
                
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                original = content
                
                # Replace imports based on depth
                # Convert "from app..." to proper relative imports
                lines = content.split('\n')
                new_lines = []
                
                for line in lines:
                    # Match "from app.X" or "from app import"
                    match = re.match(r'^from app(\.|$|\s)', line)
                    if match:
                        # Calculate how many levels to go up
                        # Current depth is from backend/app, so we need (depth) dots
                        if 'import' in line and match.group(1) == '$':
                            # "from app import" -> "from . import"
                            new_line = re.sub(r'^from app ', 'from . ', line)
                        else:
                            # "from app.X.Y" -> need to figure out correct level
                            # Get the module path after "app."
                            module_path = re.sub(r'^from app\.', '', line)
                            # Use proper relative import
                            new_line = f'from .{module_path}'
                        new_lines.append(new_line)
                    else:
                        new_lines.append(line)
                
                content = '\n'.join(new_lines)
                
                if original != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"Fixed: {filepath}")
            except Exception as e:
                print(f"Error processing {filepath}: {e}")

print("All imports fixed!")
