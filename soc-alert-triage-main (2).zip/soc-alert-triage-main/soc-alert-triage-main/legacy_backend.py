from fastapi import FastAPI
from pydantic import BaseModel
from typing import Any, Dict, List
from datetime import datetime
import json, os, uuid
import random
from datetime import datetime, timedelta
from typing import List, Optional
from database import add_feedback, list_feedback

app = FastAPI(title="Agentic AI SOC API")

class Alert(BaseModel):
    source: str
    timestamp: str
    event_type: str
    message: str
    user: str | None = None
    host: str | None = None
    src_ip: str | None = None
    dst_ip: str | None = None
    count: int | None = None
    process: str | None = None
    parent_process: str | None = None

def triage(alerts):
    joined = " ".join(a["message"].lower() for a in alerts)
    score = 20
    reasons = []
    failed_login_counts = [
        a.get("count", 0) for a in alerts if a["event_type"] == "failed_login"
    ]
    if failed_login_counts:
        score += min(30, max(failed_login_counts) // 2)
        if max(failed_login_counts) >= 10:
            reasons.append("High-volume failed authentication attempts")
    if "powershell" in joined:
        score += 20
        reasons.append("Suspicious PowerShell execution")
    if "malware" in joined or "command and control" in joined:
        c2_counts = [a.get("count", 0) or 0 for a in alerts if a["event_type"] == "malware_c2"]
        score += 20 + min(10, (max(c2_counts) // 20) if c2_counts else 0)
        reasons.append("Possible malware/C2 activity")
    if any(a["event_type"] == "privilege_escalation" for a in alerts):
        score += 15
        reasons.append("Potential privilege escalation")
    event_weights = {
        "port_scan": lambda count: min(20, (count or 0) // 25),
        "network_reconnaissance": lambda count: min(10, (count or 0) // 20),
        "large_outbound_transfer": lambda count: min(20, (count or 0) // 1000),
        "mass_file_modification": lambda count: min(20, (count or 0) // 250),
        "suspicious_encryption": lambda count: 15,
        "archive_creation": lambda count: 5,
    }
    for alert in alerts:
        weight_function = event_weights.get(alert["event_type"])
        if weight_function:
            score += weight_function(alert.get("count"))
    score += random.randint(0, 5)
    score = min(score, 100)
    severity = "Critical" if score >= 85 else "High" if score >= 65 else "Medium" if score >= 40 else "Low"
    return {
        "agent":"Alert Triage Agent",
        "classification":"Multi-stage credential compromise / malware activity",
        "priority_score":score,
        "severity":severity,
        "false_positive": score < 40,
        "reason":reasons
    }

def threat_intel(alerts):
    ips = sorted(set([x for a in alerts for x in [a.get("src_ip"), a.get("dst_ip")] if x]))
    techniques = ["T1110 Brute Force", "T1059.001 PowerShell", "T1071 Application Layer Protocol", "T1068 Exploitation for Privilege Escalation"]
    return {
        "agent":"Threat Intelligence Agent",
        "iocs":ips,
        "cve_lookup":"Demo enrichment: suspicious activity requires CVE validation against configured intelligence sources.",
        "mitre_attack":techniques,
        "reputation":"High risk based on correlated malicious indicators"
    }

def investigation(alerts, triage_result):
    timeline = [{"time":a["timestamp"],"event":a["event_type"],"source":a["source"]} for a in alerts]
    timeline.sort(key=lambda x:x["time"])
    return {
        "agent":"Investigation Agent",
        "risk_score":triage_result["priority_score"],
        "root_cause":"Likely credential compromise followed by suspicious PowerShell activity, outbound C2 communication, and possible privilege escalation.",
        "correlated_alerts":len(alerts),
        "attack_timeline":timeline
    }

def response(investigation):
    return {
        "agent":"Response Recommendation Agent",
        "containment_actions":[
            "Isolate the affected host from the network",
            "Block suspicious IP/IOC at firewall or proxy",
            "Disable or reset potentially compromised credentials"
        ],
        "recovery_actions":[
            "Run endpoint malware scan and collect forensic evidence",
            "Review privileged account activity",
            "Monitor for recurrence after remediation"
        ],
        "confidence_score":min(98, investigation["risk_score"]+4),
        "explanation":"Multiple independent security sources indicate a correlated attack chain, so immediate containment is recommended."
    }

def reporting(triage_result, intel, investigation, response_result):
    return {
        "agent":"Reporting Agent",
        "incident_id":"INC-"+uuid.uuid4().hex[:8].upper(),
        "generated_at":datetime.now().isoformat(timespec="seconds"),
        "executive_summary":f"{triage_result['severity']} incident detected with risk score {investigation['risk_score']}.",
        "attack_timeline":investigation["attack_timeline"],
        "suggested_actions":response_result["containment_actions"] + response_result["recovery_actions"]
    }

@app.get("/")
def root():
    return {"status":"Agentic AI SOC backend running"}
def random_internal_ip():
    private_ranges = [
        lambda: f"10.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}",
        lambda: f"172.{random.randint(16, 31)}.{random.randint(0, 255)}.{random.randint(1, 254)}",
        lambda: f"192.168.{random.randint(0, 255)}.{random.randint(1, 254)}"
    ]

    return random.choice(private_ranges)()

def random_external_ip():
    while True:
        address = tuple(random.randint(1, 254) for _ in range(4))
        if address[0] not in {10, 127, 192} and not (address[0] == 172 and 16 <= address[1] <= 31):
            return ".".join(map(str, address))

def generate_timestamp(base_time=None):
    from datetime import datetime, timedelta
    import random

    if base_time is None:
        base_time = datetime.now()
    elif isinstance(base_time, (int, float)):
        base_time = datetime.now() - timedelta(minutes=base_time)

    random_minutes = random.randint(1, 10080)
    random_seconds = random.randint(0, 59)

    timestamp = base_time - timedelta(
        minutes=random_minutes,
        seconds=random_seconds
    )

    return timestamp.strftime("%Y-%m-%dT%H:%M:%S")
def generate_random_scenario(exclude_scenario=None):

    scenarios = [
        "credential_compromise",
        "ransomware",
        "data_exfiltration",
        "port_scan",
        "malware_c2",
        "privilege_escalation",
        "phishing",
        "lateral_movement",
    ]

    available_scenarios = [
        item for item in scenarios if item != exclude_scenario
    ]
    scenario = random.choice(available_scenarios)

    # --------------------------------------------------------
    # 1. CREDENTIAL COMPROMISE
    # --------------------------------------------------------

    if scenario == "credential_compromise":

        user = random.choice([
            "admin",
            "administrator",
            "john",
            "alice"
        ])

        host = random.choice([
            "PC-01",
            "PC-02",
            "SERVER-01"
        ])

        attacker_ip = random_external_ip()

        alerts = [

            {
                "source": "WindowsLogs",
                "timestamp": generate_timestamp(0),
                "event_type": "failed_login",
                "user": user,
                "host": host,
                "src_ip": attacker_ip,
                "count": random.randint(15, 60),
                "message": f"Multiple failed login attempts detected for {user}",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "WindowsLogs",
                "timestamp": generate_timestamp(2),
                "event_type": "successful_login",
                "user": user,
                "host": host,
                "src_ip": attacker_ip,
                "count": 1,
                "message": "Successful login detected after repeated failures",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(4),
                "event_type": "suspicious_process",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Suspicious PowerShell process execution detected",
                "process": "powershell.exe",
                "parent_process": "winword.exe",
                "dst_ip": None
            }
        ]

        return {
            "scenario": "Credential Compromise",
            "attack_id": f"ATTACK-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 2. RANSOMWARE
    # --------------------------------------------------------

    elif scenario == "ransomware":

        host = random.choice([
            "PC-02",
            "PC-04",
            "FILE-SERVER-01"
        ])

        user = random.choice([
            "employee01",
            "john",
            "alice"
        ])

        alerts = [

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(0),
                "event_type": "suspicious_process",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Unknown executable launched from temporary directory",
                "process": "unknown.exe",
                "parent_process": "explorer.exe",
                "dst_ip": None
            },

            {
                "source": "Wazuh",
                "timestamp": generate_timestamp(2),
                "event_type": "mass_file_modification",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": random.randint(500, 5000),
                "message": "Large number of files modified within a short time",
                "process": "unknown.exe",
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Wazuh",
                "timestamp": generate_timestamp(3),
                "event_type": "suspicious_encryption",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": random.randint(100, 1000),
                "message": "Multiple files detected with suspicious encrypted extensions",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Suricata",
                "timestamp": generate_timestamp(5),
                "event_type": "malware_c2",
                "user": None,
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Possible ransomware command and control communication",
                "process": None,
                "parent_process": None,
                "dst_ip": random_external_ip()
            }
        ]

        return {
            "scenario": "Ransomware Activity",
            "attack_id": f"RANSOM-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 3. DATA EXFILTRATION
    # --------------------------------------------------------

    elif scenario == "data_exfiltration":

        user = random.choice([
            "employee01",
            "employee02",
            "finance_user"
        ])

        host = random.choice([
            "PC-05",
            "FINANCE-PC",
            "HR-PC"
        ])

        destination = random_external_ip()

        alerts = [

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(0),
                "event_type": "archive_creation",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": 1,
                "message": "Large archive file created",
                "process": "7z.exe",
                "parent_process": "explorer.exe",
                "dst_ip": None
            },

            {
                "source": "Zeek",
                "timestamp": generate_timestamp(2),
                "event_type": "large_outbound_transfer",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": random.randint(1000, 10000),
                "message": "Unusually large outbound data transfer detected",
                "process": None,
                "parent_process": None,
                "dst_ip": destination
            },

            {
                "source": "Wazuh",
                "timestamp": generate_timestamp(4),
                "event_type": "suspicious_network_activity",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": random.randint(5, 30),
                "message": "Repeated connection attempts to unknown external destination",
                "process": None,
                "parent_process": None,
                "dst_ip": destination
            }
        ]

        return {
            "scenario": "Potential Data Exfiltration",
            "attack_id": f"EXFIL-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 4. PORT SCAN
    # --------------------------------------------------------

    elif scenario == "port_scan":

        source_ip = random_external_ip()

        host = random.choice([
            "WEB-SERVER-01",
            "SERVER-01",
            "DB-SERVER"
        ])

        alerts = [

            {
                "source": "Zeek",
                "timestamp": generate_timestamp(0),
                "event_type": "port_scan",
                "user": None,
                "host": host,
                "src_ip": source_ip,
                "count": random.randint(50, 500),
                "message": "Multiple ports scanned within a short period",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Suricata",
                "timestamp": generate_timestamp(2),
                "event_type": "network_reconnaissance",
                "user": None,
                "host": host,
                "src_ip": source_ip,
                "count": random.randint(20, 100),
                "message": "Suspicious network reconnaissance activity detected",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            }
        ]

        return {
            "scenario": "Network Port Scanning",
            "attack_id": f"SCAN-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 5. MALWARE COMMAND AND CONTROL
    # --------------------------------------------------------

    elif scenario == "malware_c2":

        host = random.choice([
            "PC-03",
            "PC-06",
            "DEV-PC"
        ])

        destination = random_external_ip()

        alerts = [

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(0),
                "event_type": "suspicious_process",
                "user": random.choice(["john", "alice"]),
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Suspicious process executed from unusual location",
                "process": random.choice([
                    "rundll32.exe",
                    "mshta.exe",
                    "powershell.exe"
                ]),
                "parent_process": "explorer.exe",
                "dst_ip": None
            },

            {
                "source": "Suricata",
                "timestamp": generate_timestamp(2),
                "event_type": "malware_c2",
                "user": None,
                "host": host,
                "src_ip": None,
                "count": random.randint(10, 100),
                "message": "Repeated outbound communication to suspicious external IP",
                "process": None,
                "parent_process": None,
                "dst_ip": destination
            },

            {
                "source": "Zeek",
                "timestamp": generate_timestamp(4),
                "event_type": "suspicious_connection",
                "user": None,
                "host": host,
                "src_ip": None,
                "count": random.randint(5, 50),
                "message": "Repeated outbound connections detected",
                "process": None,
                "parent_process": None,
                "dst_ip": destination
            }
        ]

        return {
            "scenario": "Malware Command and Control",
            "attack_id": f"C2-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 6. PRIVILEGE ESCALATION
    # --------------------------------------------------------

    elif scenario == "privilege_escalation":

        user = random.choice([
            "employee01",
            "john",
            "service_user"
        ])

        host = random.choice([
            "PC-01",
            "PC-04",
            "SERVER-02"
        ])

        alerts = [

            {
                "source": "WindowsLogs",
                "timestamp": generate_timestamp(),
                "event_type": "privilege_escalation",
                "user": user,
                "host": host,
                "src_ip": random_internal_ip(),
                "count": 1,
                "message": "Unexpected administrative privilege assignment detected",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(2),
                "event_type": "suspicious_process",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Command shell launched with elevated privileges",
                "process": "cmd.exe",
                "parent_process": "powershell.exe",
                "dst_ip": None
            }
        ]

        return {
            "scenario": "Privilege Escalation",
            "attack_id": f"PRIV-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 7. PHISHING
    # --------------------------------------------------------

    elif scenario == "phishing":

        user = random.choice([
            "john",
            "alice",
            "employee03"
        ])

        host = random.choice([
            "PC-01",
            "PC-07",
            "HR-PC"
        ])

        alerts = [

            {
                "source": "WindowsLogs",
                "timestamp": generate_timestamp(0),
                "event_type": "suspicious_attachment",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": 1,
                "message": "Suspicious email attachment opened by user",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(2),
                "event_type": "suspicious_process",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Office application spawned PowerShell",
                "process": "powershell.exe",
                "parent_process": "winword.exe",
                "dst_ip": None
            },

            {
                "source": "Suricata",
                "timestamp": generate_timestamp(4),
                "event_type": "suspicious_connection",
                "user": None,
                "host": host,
                "src_ip": None,
                "count": random.randint(1, 20),
                "message": "Suspicious external connection after attachment execution",
                "process": None,
                "parent_process": None,
                "dst_ip": random_external_ip()
            }
        ]

        return {
            "scenario": "Phishing and Malicious Attachment",
            "attack_id": f"PHISH-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 8. LATERAL MOVEMENT
    # --------------------------------------------------------

    elif scenario == "lateral_movement":

        user = random.choice([
            "admin",
            "administrator",
            "service_account"
        ])

        source_ip = random_internal_ip()

        alerts = [

            {
                "source": "WindowsLogs",
                "timestamp": generate_timestamp(0),
                "event_type": "remote_login",
                "user": user,
                "host": "SERVER-01",
                "src_ip": source_ip,
                "count": random.randint(1, 10),
                "message": "Remote login from unusual internal host",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Zeek",
                "timestamp": generate_timestamp(2),
                "event_type": "suspicious_connection",
                "user": user,
                "host": "SERVER-02",
                "src_ip": source_ip,
                "count": random.randint(5, 30),
                "message": "Multiple internal connections detected between servers",
                "process": None,
                "parent_process": None,
                "dst_ip": random_internal_ip()
            },

            {
                "source": "Wazuh",
                "timestamp": generate_timestamp(4),
                "event_type": "credential_access",
                "user": user,
                "host": "SERVER-02",
                "src_ip": source_ip,
                "count": 1,
                "message": "Suspicious credential access activity detected",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            }
        ]

        return {
            "scenario": "Potential Lateral Movement",
            "attack_id": f"LATERAL-{random.randint(1000, 9999)}",
            "alerts": alerts
        }

    # --------------------------------------------------------
    # 9. BENIGN ACTIVITY
    # --------------------------------------------------------

    else:

        user = random.choice([
            "employee01",
            "employee02",
            "john",
            "alice"
        ])

        host = random.choice([
            "PC-01",
            "PC-03",
            "PC-05"
        ])

        alerts = [

            {
                "source": "WindowsLogs",
                "timestamp": generate_timestamp(0),
                "event_type": "successful_login",
                "user": user,
                "host": host,
                "src_ip": random_internal_ip(),
                "count": 1,
                "message": "Normal successful login during expected working hours",
                "process": None,
                "parent_process": None,
                "dst_ip": None
            },

            {
                "source": "Sysmon",
                "timestamp": generate_timestamp(2),
                "event_type": "normal_process",
                "user": user,
                "host": host,
                "src_ip": None,
                "count": None,
                "message": "Normal application execution detected",
                "process": "chrome.exe",
                "parent_process": "explorer.exe",
                "dst_ip": None
            }
        ]

        return {
            "scenario": "Normal / Benign Activity",
            "attack_id": f"BENIGN-{random.randint(1000, 9999)}",
            "alerts": alerts
        }


# ============================================================
# YOUR EXISTING AGENT FUNCTIONS
# ============================================================

# KEEP YOUR CURRENT FUNCTIONS HERE
#
# def triage(raw):
#     ...
#
# def threat_intel(raw):
#     ...
#
# def investigation(raw, t):
#     ...
#
# def response(inv):
#     ...
#
# def reporting(t, ti, inv, rec):
#     ...


# ============================================================
# PIPELINE ENDPOINT
# ============================================================

@app.post("/pipeline")
def run_pipeline(alerts: Optional[List[Alert]] = None):

    if alerts:
        raw = [alert.model_dump() if hasattr(alert, "model_dump") else alert.dict() for alert in alerts]
        scenario_name = "Submitted Log Analysis"
        attack_id = "SUBMITTED-" + uuid.uuid4().hex[:8].upper()
    else:
        scenario_data = generate_random_scenario()
        scenario_name = scenario_data["scenario"]
        attack_id = scenario_data["attack_id"]
        raw = scenario_data["alerts"]

    # --------------------------------------------------------
    # RUN YOUR AGENTS
    # --------------------------------------------------------

    t = triage(raw)

    ti = threat_intel(raw)

    inv = investigation(raw, t)

    rec = response(inv)

    rep = reporting(
        t,
        ti,
        inv,
        rec
    )

    # --------------------------------------------------------
    # RETURN EVERYTHING TO FRONTEND
    # --------------------------------------------------------

    return {

        "scenario": scenario_name,

        "attack_id": attack_id,

        "ingested_alerts": len(raw),

        # IMPORTANT:
        # Frontend should display these alerts
        "alerts": raw,

        "triage": t,

        "threat_intelligence": ti,

        "investigation": inv,

        "response_recommendation": rec,

        "report": rep
    }

@app.get("/sample-logs")
def sample_logs():
    with open("data/sample_logs.json") as f:
        return json.load(f)

@app.post("/feedback")
def feedback(payload: Dict[str, Any]):
    item = {"timestamp":datetime.now().isoformat(timespec="seconds"), **payload}
    return {"status":"stored","knowledge_base_entries":add_feedback(item)}

@app.get("/knowledge-base")
def knowledge_base():
    return list_feedback()
