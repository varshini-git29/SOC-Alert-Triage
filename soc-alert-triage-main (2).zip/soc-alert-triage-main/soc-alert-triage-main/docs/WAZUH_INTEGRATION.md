# Wazuh Integration Guide

This guide explains how to configure syslog forwarding from SOC Alert Triage to Wazuh.

## Overview

The SOC Alert Triage system can forward all alerts to Wazuh via syslog protocol. This allows you to:
- Centralize alerts in Wazuh for correlation and analysis
- Use Wazuh's detection rules on SOC alerts
- Create custom Wazuh responses based on alert severity
- Maintain audit trail of all security events

## Prerequisites

1. **Wazuh Manager/Agent** running and listening on syslog port
2. **Python 3.10+** (included with project)
3. **Network connectivity** from SOC Alert Triage to Wazuh syslog endpoint

## Configuration

### 1. Enable Wazuh Integration

Set environment variables or create a `.env` file:

```bash
# Enable Wazuh syslog forwarding
WAZUH_ENABLED=True
FORWARD_ALERTS_TO_WAZUH=True

# Wazuh syslog server address
WAZUH_HOST=192.168.1.100       # Wazuh manager/agent IP
WAZUH_PORT=514                  # Syslog port (default 514)
WAZUH_FACILITY=16               # Syslog facility (16=Local0)
```

### 2. Docker Compose Setup (Optional)

If you want to run Wazuh locally with Docker:

```yaml
version: '3.8'
services:
  wazuh:
    image: wazuh/wazuh:latest
    ports:
      - "514:514/udp"  # Syslog
      - "1514:1514"    # Agent
      - "514:514"      # Syslog TCP
    environment:
      - INDEXER_URL=https://wazuh.example.com
      - INDEXER_USERNAME=admin
      - INDEXER_PASSWORD=SecurePassword123
    volumes:
      - wazuh-api-logs:/var/ossec/logs
      
volumes:
  wazuh-api-logs:
```

### 3. Wazuh Agent Configuration

If using a Wazuh agent, configure it to receive syslog:

**Edit `/var/ossec/etc/ossec.conf` on Wazuh agent:**

```xml
<ossec_config>
  <remote>
    <connection>syslog</connection>
    <port>514</port>
    <protocol>udp</protocol>
  </remote>
  
  <localfile>
    <log_format>json</log_format>
    <location>alerts</location>
  </localfile>
</ossec_config>
```

Then restart Wazuh:
```bash
/var/ossec/bin/wazuh-control restart
```

## Alert Format

Alerts are forwarded to Wazuh in JSON format:

```json
{
  "alert_id": 123,
  "title": "Suspicious Login Attempt",
  "description": "Multiple failed login attempts detected",
  "severity": "high",
  "source": "Windows Security",
  "status": "open",
  "timestamp": "2026-10-06T14:30:00",
  "tags": ["authentication", "brute-force"]
}
```

**Syslog Priority Mapping:**

| Severity | Syslog Level |
|----------|-------------|
| critical | CRIT (2)    |
| high     | ERR (3)     |
| medium   | WARNING (4) |
| low      | NOTICE (5)  |
| info     | INFO (6)    |

## Wazuh Rules

Create custom rules in Wazuh to parse and respond to SOC alerts:

**Edit `/var/ossec/etc/rules/local_rules.xml`:**

```xml
<group name="soc_alerts">
  <rule id="100001" level="5">
    <match>SOC-Alert</match>
    <description>Alert forwarded from SOC Triage</description>
  </rule>
  
  <rule id="100002" level="10" parent="100001">
    <field name="severity">critical</field>
    <description>Critical alert from SOC Triage</description>
    <group>attack.discovery</group>
  </rule>
  
  <rule id="100003" level="7" parent="100001">
    <field name="severity">high</field>
    <description>High severity alert from SOC Triage</description>
    <group>attack.persistence</group>
  </rule>
</group>
```

## API Endpoints

### Check Wazuh Connectivity

```bash
curl -X GET http://localhost:8001/health
```

Response includes Wazuh connection status.

### Verify Alert Forwarding

Monitor logs:

```bash
# Check Wazuh alerts
tail -f /var/ossec/logs/alerts/alerts.json

# Check backend logs
docker logs backend-container | grep -i wazuh
```

## Troubleshooting

### Alerts Not Reaching Wazuh

1. **Check connectivity:**
   ```bash
   telnet 192.168.1.100 514
   ```

2. **Verify Wazuh is listening:**
   ```bash
   sudo netstat -tuln | grep 514
   ```

3. **Check firewall:**
   ```bash
   sudo ufw allow 514/udp
   ```

4. **Enable debug logging:**
   - Set `LOG_LEVEL=DEBUG` in configuration
   - Check backend logs for errors

### Syslog Format Issues

- Ensure Wazuh syslog port is correctly configured
- Verify facility number matches Wazuh parser settings
- Check Wazuh decoder/ruleset supports JSON payloads

### Performance

- For high-volume alerts, consider using TCP instead of UDP:
  ```python
  # Modify wazuh_service.py to use SOCK_STREAM instead of SOCK_DGRAM
  ```

## Monitoring

View forwarded alerts in Wazuh dashboard:

1. Go to **Wazuh Dashboard** → **Modules** → **Log Management**
2. Search for: `tag:soc_alerts`
3. Create custom dashboards and alerts based on severity

## Advanced Configuration

### Batch Forwarding

For better performance with many alerts:

```python
from backend.app.services.wazuh_service import get_wazuh_service

wazuh = get_wazuh_service()
alerts = db.query(Alert).filter(Alert.forwarded == False).all()
result = wazuh.send_batch_alerts([
    {
        "id": a.id,
        "title": a.title,
        "description": a.description,
        "severity": a.severity,
        "source": a.source,
        "status": a.status,
        "tags": []
    } for a in alerts
])
print(f"Sent: {result['sent']}, Failed: {result['failed']}")
```

### Custom Facility

Change Wazuh facility:
- 16 = Local0
- 17 = Local1
- 18 = Local2
- ... up to 23 = Local7

## References

- [Wazuh Syslog Format](https://documentation.wazuh.com/)
- [RFC 3164 - Syslog Protocol](https://tools.ietf.org/html/rfc3164)
- [Python Syslog Module](https://docs.python.org/3/library/syslog.html)
