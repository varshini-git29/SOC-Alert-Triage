"""
Log ingestion service for real security tool integration
Supports: Wazuh, Zeek, Suricata, Sysmon, Windows Event Logs
"""

import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


class LogParser:
    """Base parser for security tool logs"""
    
    @staticmethod
    def parse_wazuh_log(log_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse Wazuh JSON alert"""
        try:
            # Wazuh alert structure
            alert = log_data.get("alert", {})
            rule = alert.get("rule", {})
            
            severity_map = {
                "0": "info", "1": "info", "2": "low",
                "3": "low", "4": "medium", "5": "medium",
                "6": "high", "7": "high", "8": "critical", "9": "critical"
            }
            
            severity = severity_map.get(str(rule.get("level", 3)), "medium")
            
            return {
                "title": rule.get("description", "Wazuh Alert"),
                "description": json.dumps(alert),
                "severity": severity,
                "source": "Wazuh",
                "status": "open",
                "tags": rule.get("groups", [])
            }
        except Exception as e:
            logger.error(f"Failed to parse Wazuh log: {str(e)}")
            return None
    
    @staticmethod
    def parse_zeek_log(log_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse Zeek network log"""
        try:
            # Zeek log structure
            event_type = log_data.get("event_type", "unknown")
            
            severity = "medium"
            if "alert" in event_type.lower() or "attack" in event_type.lower():
                severity = "high"
            
            title_map = {
                "notice": "Network Notice",
                "weird": "Network Anomaly",
                "alert": "Network Alert",
                "ssl": "SSL/TLS Event",
                "dns": "DNS Event",
                "http": "HTTP Event"
            }
            
            title = title_map.get(event_type, f"Zeek {event_type}")
            
            return {
                "title": title,
                "description": json.dumps(log_data),
                "severity": severity,
                "source": "Zeek",
                "status": "open",
                "tags": ["network", event_type]
            }
        except Exception as e:
            logger.error(f"Failed to parse Zeek log: {str(e)}")
            return None
    
    @staticmethod
    def parse_suricata_log(log_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse Suricata IDS alert"""
        try:
            # Suricata EVE format
            event = log_data.get("event_type", "alert")
            alert_info = log_data.get("alert", {})
            
            severity = alert_info.get("severity", "medium")
            
            return {
                "title": alert_info.get("signature", "Suricata Alert"),
                "description": json.dumps(log_data),
                "severity": severity,
                "source": "Suricata",
                "status": "open",
                "tags": ["ids", alert_info.get("category", "")]
            }
        except Exception as e:
            logger.error(f"Failed to parse Suricata log: {str(e)}")
            return None
    
    @staticmethod
    def parse_sysmon_log(log_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse Sysmon event"""
        try:
            # Sysmon event structure
            event_id = log_data.get("EventID", 1)
            
            event_types = {
                1: "Process Creation",
                3: "Network Connection",
                5: "Process Terminated",
                6: "Driver Loaded",
                7: "Image Loaded",
                8: "Remote Thread Created",
                9: "Raw Access Thread",
                10: "Process Accessed",
                11: "File Created",
                12: "Registry Object Added",
                13: "Registry Value Set",
                15: "File Stream Created",
                17: "Pipe Created",
                18: "Pipe Connected",
                19: "WMI Event",
                20: "WMI Event",
                21: "WMI Event",
                22: "DNS Query",
                23: "File Delete",
                26: "Clipboard Capture",
                27: "Process Tampering",
                28: "Heur Exec Detected"
            }
            
            title = event_types.get(event_id, f"Sysmon Event {event_id}")
            
            severity = "medium"
            if event_id in [8, 10, 19, 27, 28]:
                severity = "high"
            
            return {
                "title": title,
                "description": json.dumps(log_data),
                "severity": severity,
                "source": "Sysmon",
                "status": "open",
                "tags": ["endpoint", f"event_{event_id}"]
            }
        except Exception as e:
            logger.error(f"Failed to parse Sysmon log: {str(e)}")
            return None
    
    @staticmethod
    def parse_windows_event_log(log_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse Windows Event Log"""
        try:
            event_id = log_data.get("EventID", 0)
            
            # Security event severity mapping
            if event_id in [4688, 4690, 4702, 4719]:  # Account/privilege events
                severity = "high"
            elif event_id in [4625, 4648]:  # Failed/suspicious login
                severity = "medium"
            elif event_id in [4624, 4634]:  # Normal login/logout
                severity = "low"
            else:
                severity = "medium"
            
            title = log_data.get("Title", f"Windows Event {event_id}")
            
            return {
                "title": title,
                "description": json.dumps(log_data),
                "severity": severity,
                "source": "Windows Logs",
                "status": "open",
                "tags": ["windows", f"event_{event_id}"]
            }
        except Exception as e:
            logger.error(f"Failed to parse Windows Event Log: {str(e)}")
            return None


class LogIngestorService:
    """Service for ingesting and normalizing logs from security tools"""
    
    def __init__(self, db: Session):
        self.db = db
        self.parser = LogParser()
    
    def ingest_log(self, log_data: Dict[str, Any], source: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Ingest a log and normalize it to alert format
        
        Args:
            log_data: Raw log data from security tool
            source: Log source (Wazuh, Zeek, Suricata, Sysmon, Windows Logs)
            
        Returns:
            Normalized alert dict or None if parsing failed
        """
        # Auto-detect source if not specified
        if not source:
            source = self._detect_source(log_data)
        
        # Parse based on source
        if source == "Wazuh":
            return self.parser.parse_wazuh_log(log_data)
        elif source == "Zeek":
            return self.parser.parse_zeek_log(log_data)
        elif source == "Suricata":
            return self.parser.parse_suricata_log(log_data)
        elif source == "Sysmon":
            return self.parser.parse_sysmon_log(log_data)
        elif source == "Windows Logs":
            return self.parser.parse_windows_event_log(log_data)
        else:
            logger.warning(f"Unknown log source: {source}")
            return self._parse_generic_log(log_data, source)
    
    def ingest_batch_logs(self, logs: List[Dict[str, Any]], source: Optional[str] = None) -> Dict[str, Any]:
        """
        Ingest multiple logs
        
        Args:
            logs: List of raw logs
            source: Log source
            
        Returns:
            Ingestion summary
        """
        results = {
            "total": len(logs),
            "ingested": 0,
            "failed": 0,
            "alerts": [],
            "errors": []
        }
        
        for log in logs:
            alert = self.ingest_log(log, source)
            if alert:
                results["alerts"].append(alert)
                results["ingested"] += 1
            else:
                results["failed"] += 1
                results["errors"].append(f"Failed to parse log from {source}")
        
        return results
    
    @staticmethod
    def _detect_source(log_data: Dict[str, Any]) -> str:
        """Auto-detect log source based on structure"""
        if "alert" in log_data and "rule" in log_data.get("alert", {}):
            return "Wazuh"
        elif "event_type" in log_data and "src_ip" in log_data:
            return "Zeek"
        elif "alert" in log_data and "signature" in log_data.get("alert", {}):
            return "Suricata"
        elif "EventID" in log_data:
            return "Sysmon"
        elif "EventID" in log_data and "Computer" in log_data:
            return "Windows Logs"
        else:
            return "Unknown"
    
    @staticmethod
    def _parse_generic_log(log_data: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Parse generic log format"""
        return {
            "title": log_data.get("title", f"Alert from {source}"),
            "description": json.dumps(log_data),
            "severity": log_data.get("severity", "medium"),
            "source": source,
            "status": "open",
            "tags": log_data.get("tags", [])
        }
