"""
Wazuh integration service for syslog forwarding
"""

import json
import logging
import socket
from datetime import datetime
from typing import Any, Dict, Optional
from ..core.config import settings

logger = logging.getLogger(__name__)


class WazuhSyslogService:
    """Service for forwarding alerts to Wazuh via syslog"""

    def __init__(self, 
                 wazuh_host: str = "localhost",
                 wazuh_port: int = 514,
                 facility: int = 16):  # Local0 facility
        """
        Initialize Wazuh syslog service
        
        Args:
            wazuh_host: Wazuh manager/agent syslog server address
            wazuh_port: Syslog port (default 514)
            facility: Syslog facility (16=Local0, 17=Local1, etc.)
        """
        self.wazuh_host = wazuh_host
        self.wazuh_port = wazuh_port
        self.facility = facility
        self.enabled = True
        self.socket = None
        
    def _calculate_priority(self, severity: str) -> int:
        """Calculate syslog priority from alert severity"""
        severity_map = {
            "critical": 2,  # CRIT
            "high": 3,      # ERR
            "medium": 4,    # WARNING
            "low": 5,       # NOTICE
            "info": 6       # INFO
        }
        severity_level = severity_map.get(severity.lower(), 6)
        return self.facility * 8 + severity_level
    
    def send_alert(self, 
                   alert_id: int,
                   title: str,
                   description: str,
                   severity: str,
                   source: str,
                   status: str,
                   tags: Optional[list] = None) -> bool:
        """
        Send alert to Wazuh via syslog
        
        Args:
            alert_id: Alert ID
            title: Alert title
            description: Alert description
            severity: Alert severity level
            source: Alert source system
            status: Alert status
            tags: Alert tags
            
        Returns:
            bool: True if sent successfully, False otherwise
        """
        if not self.enabled:
            return False
            
        try:
            priority = self._calculate_priority(severity)
            timestamp = datetime.utcnow().isoformat()
            
            # Build alert payload
            alert_data = {
                "alert_id": alert_id,
                "title": title,
                "description": description,
                "severity": severity,
                "source": source,
                "status": status,
                "timestamp": timestamp,
                "tags": tags or []
            }
            
            # Format syslog message
            message = json.dumps(alert_data)
            
            # Syslog header format: <PRI>TIMESTAMP HOSTNAME TAG: MESSAGE
            syslog_msg = f"<{priority}>{timestamp} SOC-Alert[{alert_id}]: {message}"
            
            # Send via UDP syslog
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(syslog_msg.encode('utf-8'), 
                       (self.wazuh_host, self.wazuh_port))
            sock.close()
            
            logger.info(f"Alert {alert_id} sent to Wazuh: {self.wazuh_host}:{self.wazuh_port}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send alert to Wazuh: {str(e)}")
            return False
    
    def send_batch_alerts(self, alerts: list) -> Dict[str, Any]:
        """
        Send multiple alerts to Wazuh
        
        Args:
            alerts: List of alert dictionaries
            
        Returns:
            dict: Summary of sent/failed alerts
        """
        results = {"sent": 0, "failed": 0, "errors": []}
        
        for alert in alerts:
            success = self.send_alert(
                alert_id=alert.get("id"),
                title=alert.get("title"),
                description=alert.get("description"),
                severity=alert.get("severity"),
                source=alert.get("source"),
                status=alert.get("status"),
                tags=alert.get("tags", [])
            )
            
            if success:
                results["sent"] += 1
            else:
                results["failed"] += 1
                results["errors"].append(f"Failed to send alert {alert.get('id')}")
        
        return results


# Global instance
wazuh_service: Optional[WazuhSyslogService] = None


def get_wazuh_service(
    wazuh_host: str = None,
    wazuh_port: int = None
) -> WazuhSyslogService:
    """Get or create Wazuh syslog service instance"""
    global wazuh_service
    
    if wazuh_service is None:
        host = wazuh_host or getattr(settings, 'WAZUH_HOST', 'localhost')
        port = wazuh_port or getattr(settings, 'WAZUH_PORT', 514)
        wazuh_service = WazuhSyslogService(wazuh_host=host, wazuh_port=port)
    
    return wazuh_service
