"""
Log ingestion API endpoints
"""

from typing import Any, Dict, List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel

from ....core.database import get_db
from ....core.config import settings
from ....services.log_ingestor_service import LogIngestorService
from ....services.alert_service import AlertService
from ....services.wazuh_service import get_wazuh_service
from ....schemas.alert import AlertResponse

router = APIRouter()


class LogIngestRequest(BaseModel):
    """Request model for log ingestion"""
    logs: List[Dict[str, Any]]
    source: str = None  # Optional, will auto-detect if not specified


class LogIngestResponse(BaseModel):
    """Response model for log ingestion"""
    total: int
    ingested: int
    failed: int
    message: str


@router.post("/ingest", response_model=LogIngestResponse)
async def ingest_logs(
    request: LogIngestRequest,
    db: Session = Depends(get_db)
) -> LogIngestResponse:
    """
    Ingest security tool logs and create alerts
    
    Supports:
    - Wazuh alerts
    - Zeek network logs
    - Suricata IDS alerts
    - Sysmon events
    - Windows Event Logs
    
    Args:
        request: LogIngestRequest with logs and source
        db: Database session
        
    Returns:
        Ingestion summary
    """
    try:
        # Initialize services
        ingestor = LogIngestorService(db)
        alert_service = AlertService(db)
        wazuh_service = get_wazuh_service(
            wazuh_host=settings.WAZUH_HOST,
            wazuh_port=settings.WAZUH_PORT
        ) if settings.WAZUH_ENABLED else None
        
        ingested_count = 0
        failed_count = 0
        
        # Process each log
        for log in request.logs:
            # Parse and normalize log
            alert_data = ingestor.ingest_log(log, request.source)
            
            if alert_data:
                # Create alert in database
                from ....schemas.alert import AlertCreate
                alert_create = AlertCreate(**alert_data)
                alert = await alert_service.create_alert(alert_create)
                ingested_count += 1
                
                # Forward to Wazuh if enabled
                if settings.FORWARD_ALERTS_TO_WAZUH and wazuh_service:
                    wazuh_service.send_alert(
                        alert_id=alert.id,
                        title=alert.title,
                        description=alert.description,
                        severity=alert.severity,
                        source=alert.source,
                        status=alert.status
                    )
            else:
                failed_count += 1
        
        return LogIngestResponse(
            total=len(request.logs),
            ingested=ingested_count,
            failed=failed_count,
            message=f"Successfully ingested {ingested_count}/{len(request.logs)} logs"
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Log ingestion failed: {str(e)}"
        )


@router.post("/ingest/wazuh")
async def ingest_wazuh_alert(
    alert_data: Dict[str, Any],
    db: Session = Depends(get_db)
) -> AlertResponse:
    """
    Ingest a Wazuh alert directly
    
    This endpoint is optimized for Wazuh webhook integration
    """
    try:
        ingestor = LogIngestorService(db)
        alert_service = AlertService(db)
        
        # Parse Wazuh alert
        parsed_alert = ingestor.ingest_log(alert_data, "Wazuh")
        
        if not parsed_alert:
            raise HTTPException(
                status_code=400,
                detail="Failed to parse Wazuh alert"
            )
        
        # Create alert
        from ....schemas.alert import AlertCreate
        alert_create = AlertCreate(**parsed_alert)
        alert = await alert_service.create_alert(alert_create)
        
        return AlertResponse.from_orm(alert)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Wazuh ingestion failed: {str(e)}"
        )


@router.post("/ingest/zeek")
async def ingest_zeek_log(
    log_data: Dict[str, Any],
    db: Session = Depends(get_db)
) -> AlertResponse:
    """Ingest a Zeek network log"""
    try:
        ingestor = LogIngestorService(db)
        alert_service = AlertService(db)
        
        parsed_alert = ingestor.ingest_log(log_data, "Zeek")
        
        if not parsed_alert:
            raise HTTPException(status_code=400, detail="Failed to parse Zeek log")
        
        from ....schemas.alert import AlertCreate
        alert_create = AlertCreate(**parsed_alert)
        alert = await alert_service.create_alert(alert_create)
        
        return AlertResponse.from_orm(alert)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Zeek ingestion failed: {str(e)}"
        )


@router.post("/ingest/suricata")
async def ingest_suricata_alert(
    alert_data: Dict[str, Any],
    db: Session = Depends(get_db)
) -> AlertResponse:
    """Ingest a Suricata IDS alert"""
    try:
        ingestor = LogIngestorService(db)
        alert_service = AlertService(db)
        
        parsed_alert = ingestor.ingest_log(alert_data, "Suricata")
        
        if not parsed_alert:
            raise HTTPException(status_code=400, detail="Failed to parse Suricata alert")
        
        from ....schemas.alert import AlertCreate
        alert_create = AlertCreate(**parsed_alert)
        alert = await alert_service.create_alert(alert_create)
        
        return AlertResponse.from_orm(alert)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Suricata ingestion failed: {str(e)}"
        )


@router.post("/ingest/sysmon")
async def ingest_sysmon_event(
    event_data: Dict[str, Any],
    db: Session = Depends(get_db)
) -> AlertResponse:
    """Ingest a Sysmon event"""
    try:
        ingestor = LogIngestorService(db)
        alert_service = AlertService(db)
        
        parsed_alert = ingestor.ingest_log(event_data, "Sysmon")
        
        if not parsed_alert:
            raise HTTPException(status_code=400, detail="Failed to parse Sysmon event")
        
        from ....schemas.alert import AlertCreate
        alert_create = AlertCreate(**parsed_alert)
        alert = await alert_service.create_alert(alert_create)
        
        return AlertResponse.from_orm(alert)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Sysmon ingestion failed: {str(e)}"
        )


@router.get("/ingest/status")
async def ingest_status() -> Dict[str, Any]:
    """Get log ingestion status"""
    return {
        "status": "active",
        "wazuh_forwarding": settings.FORWARD_ALERTS_TO_WAZUH,
        "wazuh_enabled": settings.WAZUH_ENABLED,
        "supported_sources": [
            "Wazuh",
            "Zeek",
            "Suricata",
            "Sysmon",
            "Windows Logs"
        ]
    }
