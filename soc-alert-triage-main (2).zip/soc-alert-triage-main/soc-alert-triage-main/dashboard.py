import streamlit as st
import json
import os
from pathlib import Path

if "DATABASE_URL" not in os.environ:
    try:
        os.environ["DATABASE_URL"] = st.secrets["DATABASE_URL"]
    except (KeyError, FileNotFoundError):
        pass

from legacy_backend import generate_random_scenario, investigation, reporting, response, threat_intel, triage
from database import add_feedback, list_feedback

PROJECT_DIR = Path(__file__).resolve().parent
SAMPLE_LOGS_FILE = PROJECT_DIR / "data" / "sample_logs.json"
st.set_page_config(page_title="Agentic AI SOC", layout="wide")
st.title("🛡️ Agentic AI for SOC Alert Triage & Response Recommendation")
st.caption("Review Demonstration Prototype — 5-Agent SOC Workflow")

with SAMPLE_LOGS_FILE.open(encoding="utf-8") as sample_file:
    sample = json.load(sample_file)

st.subheader("1. Security Log Sources")
st.write("Sysmon • Zeek • Wazuh • Suricata • Windows Logs")
st.dataframe(sample, use_container_width=True)

if st.button("🚀 Run Full Agentic Pipeline", type="primary"):
    scenario = generate_random_scenario(st.session_state.get("last_scenario"))
    st.session_state.last_scenario = scenario["scenario"]
    raw = scenario["alerts"]
    triage_result = triage(raw)
    intel_result = threat_intel(raw)
    investigation_result = investigation(raw, triage_result)
    response_result = response(investigation_result)
    report_result = reporting(triage_result, intel_result, investigation_result, response_result)
    st.session_state.result = {
        "scenario": scenario["scenario"],
        "attack_id": scenario["attack_id"],
        "ingested_alerts": len(raw),
        "alerts": raw,
        "triage": triage_result,
        "threat_intelligence": intel_result,
        "investigation": investigation_result,
        "response_recommendation": response_result,
        "report": report_result,
    }

if "result" in st.session_state:
    x=st.session_state.result
    st.info(f"Scenario: {x['scenario']} | Attack ID: {x['attack_id']}")
    st.success(f"{x['ingested_alerts']} alerts ingested successfully")

    c1,c2,c3 = st.columns(3)
    c1.metric("Severity", x["triage"]["severity"])
    c2.metric("Priority / Risk", x["investigation"]["risk_score"])
    c3.metric("Response Confidence", x["response_recommendation"]["confidence_score"])

    st.header("🤖 Agent Outputs")
    for key, title in [
        ("triage","1. Alert Triage Agent"),
        ("threat_intelligence","2. Threat Intelligence Agent"),
        ("investigation","3. Investigation Agent"),
        ("response_recommendation","4. Response Recommendation Agent"),
        ("report","5. Reporting Agent")
    ]:
        with st.expander(title, expanded=True):
            st.json(x[key])

    st.header("👨‍💻 Security Analyst Feedback")
    decision = st.radio("Decision", ["Accept Recommendation","Modify Recommendation","Reject Recommendation"])
    comment = st.text_area("Analyst comments")
    if st.button("Store Feedback in Knowledge Base"):
        entry_count = add_feedback({
            "decision": decision,
            "comment": comment,
            "incident": x["report"]["incident_id"],
        })
        st.success(f"Feedback stored. Knowledge Base entries: {entry_count}")

st.header("📚 Knowledge Base")
if st.button("Refresh Knowledge Base"):
    st.json(list_feedback())
